const consentScreen = document.getElementById("consentScreen");
const mainScreen = document.getElementById("mainScreen");
const myCodeEl = document.getElementById("myCode");
const statusEl = document.getElementById("status");
const pairSection = document.getElementById("pairSection");
const trollSection = document.getElementById("trollSection");
const pairedBadge = document.getElementById("pairedBadge");

document.getElementById("acceptBtn").addEventListener("click", () => {
  consentScreen.style.display = "none";
  mainScreen.style.display = "block";
});

window.api.onMyCode((code) => (myCodeEl.textContent = code));
window.api.onStatus((text) => (statusEl.textContent = text));

window.api.onPaired((withCode) => {
  pairSection.style.display = "none";
  trollSection.style.display = "block";
  pairedBadge.style.display = "block";
  pairedBadge.textContent = `✅ Paired with ${withCode}`;
});

window.api.onUnpaired((byCode) => {
  pairSection.style.display = "block";
  trollSection.style.display = "none";
  pairedBadge.style.display = "none";
  statusEl.textContent = byCode ? `${byCode} unpaired from you.` : "Unpaired.";
});

document.getElementById("pairBtn").addEventListener("click", () => {
  const code = document.getElementById("targetCode").value.trim();
  if (code.length < 4) return;
  window.api.requestPair(code);
  statusEl.textContent = `Pairing request sent to ${code}...`;
});

document.getElementById("unpairBtn").addEventListener("click", () => {
  window.api.unpair();
});

document.getElementById("pickImageBtn").addEventListener("click", async () => {
  const filePath = await window.api.pickImage();
  if (!filePath) return;
  statusEl.textContent = "Sending wallpaper...";
  try {
    await window.api.sendWallpaper(filePath);
    statusEl.textContent = "Sent! Waiting for them to see it 😈";
  } catch (err) {
    statusEl.textContent = `Failed to send: ${err.message}`;
  }
});
