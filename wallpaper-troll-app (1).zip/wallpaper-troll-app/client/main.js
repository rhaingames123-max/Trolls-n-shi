const { app, BrowserWindow, ipcMain, dialog, Notification } = require("electron");
const path = require("path");
const fs = require("fs");
const os = require("os");
const WebSocket = require("ws");

// ---- CONFIGURE THIS ----
// After deploying the relay server (see README "Deploying so it works
// across different networks"), paste your server's URL here. Use wss://
// (not ws://) since hosts like Render/Railway serve over TLS.
// Example: "wss://wallpaper-troll-server.onrender.com"
const DEFAULT_RELAY_URL = "wss://YOUR-SERVER-URL-HERE.onrender.com";

// Falls back to DEFAULT_RELAY_URL above, but can still be overridden with
// an env var if you ever want to point at a different server temporarily.
const RELAY_URL = process.env.RELAY_URL || DEFAULT_RELAY_URL;

let mainWindow;
let ws;
let myCode = null;
let pairedWithCode = null;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 420,
    height: 560,
    resizable: false,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });
  mainWindow.loadFile("index.html");
}

function toRenderer(channel, payload) {
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send(channel, payload);
  }
}

function connectToRelay() {
  if (RELAY_URL.includes("YOUR-SERVER-URL-HERE")) {
    toRenderer(
      "status",
      "No server configured yet — edit DEFAULT_RELAY_URL at the top of main.js with your deployed server's URL."
    );
    return;
  }

  ws = new WebSocket(RELAY_URL);

  ws.on("open", () => toRenderer("status", "Connected to relay server."));

  ws.on("message", async (raw) => {
    const msg = JSON.parse(raw.toString());

    switch (msg.type) {
      case "registered":
        myCode = msg.code;
        toRenderer("my-code", myCode);
        break;

      case "pair-request": {
        // Consent was already given up front on the disclosure screen at
        // launch (see index.html / renderer.js "I Understand" step) - that
        // screen is what makes sharing your code meaningful. Entering
        // someone's code is the deliberate act of granting them access,
        // so no second per-request popup is shown here.
        ws.send(JSON.stringify({ type: "pair-response", code: msg.fromCode, accept: true }));
        break;
      }

      case "paired":
        pairedWithCode = msg.withCode;
        toRenderer("paired", pairedWithCode);
        break;

      case "pair-declined":
        toRenderer("status", `${msg.byCode} declined your pairing request.`);
        break;

      case "pair-error":
        toRenderer("status", `Pairing error: ${msg.reason}`);
        break;

      case "unpaired":
        pairedWithCode = null;
        toRenderer("unpaired", msg.byCode);
        break;

      case "set-wallpaper":
        await handleIncomingWallpaper(msg);
        break;

      case "error":
        toRenderer("status", msg.reason);
        break;
    }
  });

  ws.on("close", () => {
    toRenderer("status", "Disconnected from relay server. Retrying in 3s...");
    setTimeout(connectToRelay, 3000);
  });

  ws.on("error", () => {
    toRenderer("status", "Could not reach relay server.");
  });
}

async function handleIncomingWallpaper(msg) {
  try {
    const buffer = Buffer.from(msg.imageBase64, "base64");
    const tmpPath = path.join(os.tmpdir(), `wallpaper-troll-${Date.now()}.png`);
    fs.writeFileSync(tmpPath, buffer);

    const { setWallpaper } = await import("wallpaper");
    await setWallpaper(tmpPath);

    new Notification({
      title: "Wallpaper Troll",
      body: `${msg.fromCode} just changed your wallpaper!`,
    }).show();

    toRenderer("status", `${msg.fromCode} changed your wallpaper.`);
  } catch (err) {
    toRenderer("status", `Failed to set wallpaper: ${err.message}`);
  }
}

// ---- IPC handlers (called from renderer via preload) ----

ipcMain.handle("request-pair", (_e, targetCode) => {
  ws.send(JSON.stringify({ type: "pair-request", code: targetCode.toUpperCase() }));
});

ipcMain.handle("unpair", () => {
  ws.send(JSON.stringify({ type: "unpair" }));
  pairedWithCode = null;
});

ipcMain.handle("send-wallpaper", async (_e, filePath) => {
  if (!pairedWithCode) throw new Error("Not paired with anyone.");
  const buffer = fs.readFileSync(filePath);
  ws.send(
    JSON.stringify({
      type: "set-wallpaper",
      imageBase64: buffer.toString("base64"),
    })
  );
});

ipcMain.handle("pick-image", async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ["openFile"],
    filters: [{ name: "Images", extensions: ["png", "jpg", "jpeg"] }],
  });
  if (result.canceled || result.filePaths.length === 0) return null;
  return result.filePaths[0];
});

app.whenReady().then(() => {
  createWindow();
  connectToRelay();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
