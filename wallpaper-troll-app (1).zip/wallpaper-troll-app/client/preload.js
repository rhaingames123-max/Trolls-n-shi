const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("api", {
  requestPair: (code) => ipcRenderer.invoke("request-pair", code),
  unpair: () => ipcRenderer.invoke("unpair"),
  pickImage: () => ipcRenderer.invoke("pick-image"),
  sendWallpaper: (filePath) => ipcRenderer.invoke("send-wallpaper", filePath),

  onMyCode: (cb) => ipcRenderer.on("my-code", (_e, code) => cb(code)),
  onPaired: (cb) => ipcRenderer.on("paired", (_e, code) => cb(code)),
  onUnpaired: (cb) => ipcRenderer.on("unpaired", (_e, code) => cb(code)),
  onStatus: (cb) => ipcRenderer.on("status", (_e, text) => cb(text)),
});
