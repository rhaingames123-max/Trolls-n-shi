# Wallpaper Troll

Pair with a friend using a short code, then swap each other's desktop wallpaper for laughs.
Works on **macOS and Windows** from one codebase (Electron). Nothing happens without the
other person explicitly clicking "Accept" on a pairing request first.

## How it works
1. Both of you launch the app. On first launch you see a plain-language disclosure screen:
   *"Anyone you share your code with can change your wallpaper at any time, without asking
   again — including while you're away. Only share your code with someone you're okay with
   having that ability."* You have to click "I Understand — Continue" to get past it.
2. After accepting, you get your 6-character code.
3. Trade codes with your friend and enter theirs — pairing completes immediately, no second
   popup, since you both already agreed to the terms up front.
4. Either of you can pick an image and send it — it becomes the other's wallpaper, any time,
   even while they're not at their computer.
5. Either side can hit "Unpair" any time to stop, or just quit the app.

**Your code is effectively a password.** Anyone who has it can pair with you and start
changing your wallpaper, so don't post it publicly — only give it to the specific friend(s)
you want to have access. The relay server never stores images or wallpaper data — it just
passes messages between two paired sockets.

## 1. Run the relay server
You (or whoever's hosting) needs one relay server that both clients connect to.

```bash
cd server
npm install
npm start
# -> Wallpaper Troll relay server listening on ws://0.0.0.0:8080
```

For friends on different networks, deploy this somewhere reachable (a $5 VPS, Render, Railway,
Fly.io, etc.) and open port 8080 (or put it behind a reverse proxy with TLS and use `wss://`).
If you're all on the same Wi-Fi, `ws://<your-laptop-LAN-IP>:8080` works fine too.

## 2. Run the client app
The relay URL is now baked into the app so you don't need to type an environment variable
every time. Open `client/main.js`, find this near the top:

```js
const DEFAULT_RELAY_URL = "wss://YOUR-SERVER-URL-HERE.onrender.com";
```

and replace it with your actual deployed server URL (see the deployment section below if you
haven't set one up yet). Do this once, before building/sharing the app with your friend —
both of you should be running a copy of the app pointed at the *same* URL.

Then, each person runs:

```bash
cd client
npm install
npm start
```

That's it — no `RELAY_URL=...` needed anymore. (You can still override it temporarily with
the environment variable if you ever want to test against a different server.)

## 3. Deploying the relay server so it works across different networks
If you and your friend won't be on the same Wi-Fi, deploy the `server/` folder somewhere
always-on and public. Render's free tier works well:

1. Push the contents of `server/` (`index.js`, `package.json`) to a GitHub repo.
2. On [render.com](https://render.com), click **New +** → **Web Service**, connect that repo.
3. Set Build Command to `npm install` and Start Command to `npm start`. Free tier is fine.
4. Render gives you a public URL like `wallpaper-troll-server.onrender.com` — your server is
   then reachable at `wss://wallpaper-troll-server.onrender.com`. Paste that into
   `DEFAULT_RELAY_URL` in `main.js` as described above.

Note: Render's free tier sleeps after ~15 minutes idle and takes 30-60s to wake on the next
connection — fine for a prank app, just expect a short "Connecting..." the first time each
session. Railway is a free-tier alternative that doesn't sleep the same way.

## 4. Package it as a real double-click app (optional)
Once your server URL is baked in and everything works, build installable apps for both
platforms so nobody has to touch a terminal:

```bash
cd client
npm run dist
```

This uses `electron-builder` to produce a `.dmg` for macOS and an installer `.exe` for Windows
(you'll typically want to build the Mac version on a Mac and the Windows version on Windows,
or use CI).

## Notes / things to customize
- **Wallpaper setting** uses the [`wallpaper`](https://www.npmjs.com/package/wallpaper) npm
  package, which handles both macOS (`osascript`) and Windows (`SystemParametersInfo`) under
  the hood — no platform-specific code needed on your end.
- **Consent is enforced server-side and client-side**: the relay only forwards messages between
  two codes that both agreed to pair, and the receiving app always shows a native
  accept/decline dialog before any pairing completes.
- Want a "revert to original wallpaper" button? Have the client save the current wallpaper path
  (`wallpaper.get()`) before overwriting it, and add an IPC handler to restore it.
- Want group trolling instead of 1-on-1? Extend the server's pairing model to "rooms" instead of
  single pairs — the message-relay logic barely changes.
